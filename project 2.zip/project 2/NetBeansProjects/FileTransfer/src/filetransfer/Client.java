/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filetransfer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

/**
 *
 * @author ash
 */
public class Client {

    public static void main(String args[]) throws Exception {

        Socket s = new Socket("localhost", 4567);

        //sending the file
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
        BufferedReader fbr = new BufferedReader(new FileReader("send.txt"));
        String line = fbr.readLine();
        while (line != null) {
          
            bw.write(line);
            bw.newLine();
            bw.flush();
            line = fbr.readLine();
        }
        bw.write("EOF");
        bw.newLine();
        bw.flush();

        
        //receiving a file
         //reading the file\
        BufferedReader br=new BufferedReader(new InputStreamReader(s.getInputStream()));
        
        String recevied;
        recevied=br.readLine();
        while(!recevied.equals("EOF")){
          
            System.out.println(recevied);
            recevied=br.readLine();   
            
        }
       
        br.close();
        bw.close();
        fbr.close();
        
    }
}
