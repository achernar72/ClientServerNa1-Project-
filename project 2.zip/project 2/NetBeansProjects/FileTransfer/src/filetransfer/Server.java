
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import jdk.jfr.events.FileReadEvent;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author ash
 */
public class Server {

    public static void main(String args[]) throws Exception {
        ServerSocket ss = new ServerSocket(4567);
        Socket s = ss.accept();

        //reading the file\
        BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
        BufferedWriter fbw = new BufferedWriter(new FileWriter("temp.txt"));
        String recevied;
        recevied = br.readLine();
        while (!recevied.equals("EOF")) {
             System.out.println(recevied);
            fbw.write(recevied);
            fbw.newLine();
            recevied = br.readLine();
           
        }
        
        fbw.write("Line added by server\none more line added by server");
        
        fbw.close();

        //sending the file
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
        BufferedReader fbr = new BufferedReader(new FileReader("temp.txt"));
        String line = fbr.readLine();
        while (line != null) {

            bw.write(line);
            bw.newLine();
            bw.flush();
            line = fbr.readLine();
        }
        bw.write("EOF");
        bw.newLine();
        bw.flush();

        //closing
        br.close();
        bw.close();
        fbr.close();
        fbw.close();
    }
}
