/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.client;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ash
 */
public class Server {

    public static void main(String args[]) throws Exception {

        ServerSocket ss = new ServerSocket(5678);
        Socket s = ss.accept();

        Thread read = new Thread() {
            public void run() {
                BufferedReader br = null;
                try {
                    while (true) {
                        br = new BufferedReader(new InputStreamReader(s.getInputStream()));
                        String line=br.readLine();
                        System.out.println("From Client:" + line);
                        if(line.contains("Bye from")){
                        System.exit(0);
                        
                        }
                    }
                } catch (Exception ex) {
                    try {
                        br.close();
                        s.close();
                    } catch (IOException ex1) {
                        Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex1);
                    }
                }
            }
        };
        read.start();

        //writing
        Thread write = new Thread() {
            public void run() {
                BufferedWriter bw = null;
                try {

                    bw = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
                    BufferedReader console = new BufferedReader(new InputStreamReader(System.in));
                    //System.out.print("Server:");
                    while (true) {
                        bw.write(console.readLine());
                        bw.newLine();
                        bw.flush();
                    }
                } catch (Exception ex) {

                    try {
                        s.close();
                        ss.close();
                        bw.close();
                    } catch (Exception ex1) {
                        Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex1);
                    }

                }

            }
        };
        write.start();

    }
}
